# -*- coding: utf-8 -*-
"""
SOTA 训练器
PRD 3.2 实现

特性:
- AdamW 优化器
- ReduceLROnPlateau 调度器
- 熔断机制
- 动态 IC 监控
- Checkpoint 保存
"""

import time
import os
from pathlib import Path
from typing import Dict, Optional, Callable, Tuple
import numpy as np
import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
import torch.backends.cudnn as cudnn

# 使用新的 torch.amp API (避免弃用警告)
from torch.amp import autocast, GradScaler

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.config import Config
from utils.logger import get_logger
from utils.seeder import seed_everything, get_device, clear_gpu_memory
from models.finmamba import FinMamba, AlphaModel
from models.losses import CombinedLoss, calculate_rank_ic

logger = get_logger("Trainer")

# PyTorch 性能优化
def _optimize_pytorch():
    """优化 PyTorch 设置"""
    if torch.cuda.is_available():
        # 启用 cudnn benchmark（自动寻找最优算法）
        cudnn.benchmark = True
        logger.info("✓ 启用 cudnn.benchmark")
        
        # 启用 TF32（TensorFloat-32）加速
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        logger.info("✓ 启用 TF32 加速")
        
        # 设置 CUDA 内存分配策略（使用新的环境变量名）
        os.environ['PYTORCH_ALLOC_CONF'] = 'max_split_size_mb:512'
        logger.info("✓ CUDA 内存分配策略: max_split_size_mb=512")
        
        # 清理 CUDA 缓存
        torch.cuda.empty_cache()
        logger.info("✓ 清理 CUDA 缓存")
    
    # 设置 PyTorch 线程数
    import multiprocessing
    cpu_count = multiprocessing.cpu_count()
    torch.set_num_threads(cpu_count)
    logger.info(f"✓ PyTorch 线程数: {cpu_count}")

# 初始化优化
_optimize_pytorch()


class StopTrainingError(Exception):
    """训练熔断异常"""
    pass


class Trainer:
    """
    SOTA 训练器
    
    特性:
    - IC 监控与早停
    - 动态学习率调整
    - 混合精度训练
    - Checkpoint 管理
    """
    
    def __init__(
        self,
        model: nn.Module = None,
        train_loader: DataLoader = None,
        val_loader: DataLoader = None,
        lr: float = None,
        weight_decay: float = None,
        max_epochs: int = None,
        patience: int = None,
        use_amp: bool = True,
        device: torch.device = None
    ):
        """
        初始化训练器
        
        Args:
            model: 模型实例
            train_loader: 训练数据加载器
            val_loader: 验证数据加载器
            lr: 学习率
            weight_decay: 权重衰减
            max_epochs: 最大训练轮数
            patience: 早停耐心值
            use_amp: 是否使用混合精度
            device: 计算设备
        """
        # 设置随机种子
        seed_everything(Config.SEED)
        
        # 设备
        self.device = device or get_device()
        
        # 模型
        self.model = model or AlphaModel()
        self.model = self.model.to(self.device)
        
        # 数据加载器
        self.train_loader = train_loader
        self.val_loader = val_loader
        
        # 超参数
        self.lr = lr or Config.LR_INIT
        self.weight_decay = weight_decay or Config.WEIGHT_DECAY
        self.max_epochs = max_epochs or Config.MAX_EPOCHS
        self.patience = patience or Config.PATIENCE
        self.use_amp = use_amp and torch.cuda.is_available()
        
        # 优化器: AdamW
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=self.lr,
            weight_decay=self.weight_decay
        )
        
        # 调度器: ReduceLROnPlateau - 更保守的学习率调度
        self.scheduler = ReduceLROnPlateau(
            self.optimizer,
            mode='max',  # 监控 IC (越大越好)
            factor=0.3,  # 更保守的学习率衰减因子
            patience=2,  # 更严格的 patience
            min_lr=5e-7,  # 更低的最小学习率
            threshold=0.001,  # 更小的阈值，只在 IC 有明显提升时才调整
            threshold_mode='abs'  # 绝对阈值
        )
        
        # 上一次的学习率（用于检测学习率变化）
        self._last_lr = self.lr
        
        # 损失函数 - 平衡各项损失，减少过拟合
        self.criterion = CombinedLoss(
            mse_weight=0.2,    # 进一步降低MSE权重，减少过拟合
            rank_weight=1.0,   # 降低排序权重，避免过度拟合排序
            ic_weight=0.1      # 进一步降低IC权重，避免过度拟合IC指标
        )
        
        # 混合精度 - 使用新的 API
        self.scaler = GradScaler('cuda') if self.use_amp else None
        
        # 训练状态
        self.best_ic = -float('inf')
        self.best_epoch = 0
        self.bad_epoch_count = 0
        self.current_epoch = 0
        
        # 历史记录
        self.history = {
            'train_loss': [],
            'val_loss': [],
            'val_ic': [],
            'lr': []
        }
        
        # 回调函数
        self.callbacks = {
            'on_epoch_end': None,
            'on_batch_end': None,
            'on_train_end': None
        }
        
        # 停止标志
        self._stop_flag = False
        
        logger.info("Trainer initialized")
        logger.info(f"Model parameters: {sum(p.numel() for p in self.model.parameters()):,}")
        logger.info(f"Device: {self.device}")
        logger.info(f"AMP: {self.use_amp}")
    
    def set_callback(self, name: str, callback: Callable):
        """设置回调函数"""
        if name in self.callbacks:
            self.callbacks[name] = callback
    
    def train_epoch(self) -> Dict:
        """
        训练一个 epoch
        
        Returns:
            训练指标字典
        """
        self.model.train()
        total_loss = 0.0
        n_batches = 0
        total_batches = len(self.train_loader)
        
        # 打印 epoch 开始信息
        print(f"[Train Epoch {self.current_epoch+1}] Total batches: {total_batches}", flush=True)
        
        import time
        epoch_batch_start = time.time()
        
        for batch_idx, batch_data in enumerate(self.train_loader):
            if self._stop_flag:
                break
            
            # 解包批次数据 (支持新旧格式)
            if len(batch_data) == 4:
                X, y, industry_ids, info = batch_data
                industry_ids = industry_ids.to(self.device, non_blocking=True)
            else:
                X, y, info = batch_data
                industry_ids = None
            
            # 确保输入数据类型正确，转换为float32
            X = X.float().to(self.device, non_blocking=True)  # 显式转换为float32
            y = y.float().to(self.device, non_blocking=True)  # 显式转换为float32
            
            self.optimizer.zero_grad()
            
            if self.use_amp:
                with autocast('cuda'):
                    pred = self.model(X, industry_ids)  # 传入行业ID
                    loss, loss_dict = self.criterion(pred, y)
                
                self.scaler.scale(loss).backward()
                
                # 启用梯度裁剪以减少过拟合和提高稳定性
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)  # 添加梯度裁剪
                
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                pred = self.model(X, industry_ids)  # 传入行业ID
                loss, loss_dict = self.criterion(pred, y)
                loss.backward()
                
                # 启用梯度裁剪以减少过拟合
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=0.5)
                
                self.optimizer.step()
            
            total_loss += loss_dict['total']
            n_batches += 1
            
            # 每 100 个 batch 显示一次进度 (减少频率以提升速度)
            if (batch_idx + 1) % 100 == 0 or batch_idx == 0 or batch_idx == total_batches - 1:
                progress_pct = 100.0 * (batch_idx + 1) / total_batches
                avg_loss_so_far = total_loss / n_batches
                
                # 计算速度
                elapsed = time.time() - epoch_batch_start
                samples_processed = (batch_idx + 1) * self.train_loader.batch_size
                speed = samples_processed / elapsed if elapsed > 0 else 0
                
                # 估计剩余时间
                remaining_batches = total_batches - batch_idx - 1
                eta_seconds = (remaining_batches / (batch_idx + 1)) * elapsed if batch_idx > 0 else 0
                
                msg = (
                    f"  Batch {batch_idx+1}/{total_batches} ({progress_pct:.1f}%) | "
                    f"Loss: {avg_loss_so_far:.4f} | "
                    f"Speed: {speed:.0f} samples/s | "
                    f"ETA: {eta_seconds:.0f}s"
                )
                print(msg, flush=True)
                # 减少日志输出频率（只在每 200 个 batch 记录日志）
                if (batch_idx + 1) % 200 == 0:
                    logger.info(msg)
            
            # Batch 回调
            if self.callbacks['on_batch_end']:
                self.callbacks['on_batch_end'](batch_idx, total_batches, loss_dict)
        
        # 计算平均值
        avg_loss = total_loss / max(n_batches, 1)
        
        return {
            'loss': avg_loss
        }
    
    @torch.no_grad()
    def validate(self) -> Dict:
        """
        验证
        
        Returns:
            验证指标字典
        """
        self.model.eval()
        total_loss = 0.0
        all_preds = []
        all_targets = []
        n_batches = 0
        
        for batch_data in self.val_loader:
            # 解包批次数据 (支持新旧格式)
            if len(batch_data) == 4:
                X, y, industry_ids, info = batch_data
                industry_ids = industry_ids.to(self.device, non_blocking=True)
            else:
                X, y, info = batch_data
                industry_ids = None
            
            # 确保输入数据类型正确，转换为float32
            X = X.float().to(self.device, non_blocking=True)  # 显式转换为float32
            y = y.float().to(self.device, non_blocking=True)  # 显式转换为float32
            
            if self.use_amp:
                with autocast('cuda'):
                    pred = self.model(X, industry_ids)  # 传入行业ID
                    loss, loss_dict = self.criterion(pred, y)
            else:
                pred = self.model(X, industry_ids)  # 传入行业ID
                loss, loss_dict = self.criterion(pred, y)
            
            total_loss += loss_dict['total']
            all_preds.append(pred.cpu())
            all_targets.append(y.cpu())
            n_batches += 1
        
        # 计算 IC
        all_preds = torch.cat(all_preds)
        all_targets = torch.cat(all_targets)
        val_ic = calculate_rank_ic(all_preds, all_targets)
        
        avg_loss = total_loss / max(n_batches, 1)
        
        return {
            'loss': avg_loss,
            'ic': val_ic,
            'samples': len(all_preds)
        }
    
    def train(self) -> Dict:
        """
        完整训练流程
        
        Returns:
            训练历史记录
        """
        logger.info(f"Starting training: {self.max_epochs} epochs")
        start_time = time.time()
        
        # 用于计算训练速度
        epoch_times = []
        
        try:
            for epoch in range(self.max_epochs):
                if self._stop_flag:
                    logger.info("Training stopped by user")
                    break
                
                self.current_epoch = epoch
                epoch_start = time.time()
                
                # 训练
                train_metrics = self.train_epoch()
                
                # 验证
                val_metrics = self.validate()
                
                # 更新学习率
                self.scheduler.step(val_metrics['ic'])
                current_lr = self.optimizer.param_groups[0]['lr']
                
                # 检测学习率是否发生变化（替代已弃用的 verbose 参数）
                if current_lr != self._last_lr:
                    logger.info(f"Learning rate reduced: {self._last_lr:.2e} -> {current_lr:.2e}")
                    self._last_lr = current_lr
                
                # 记录历史
                self.history['train_loss'].append(train_metrics['loss'])
                self.history['val_loss'].append(val_metrics['loss'])
                self.history['val_ic'].append(val_metrics['ic'])
                self.history['lr'].append(current_lr)
                
                # 计算时间统计
                epoch_time = time.time() - epoch_start
                epoch_times.append(epoch_time)
                
                # 计算训练速度 (samples/sec)
                train_samples = len(self.train_loader.dataset) if hasattr(self.train_loader, 'dataset') else len(self.train_loader) * 64
                samples_per_sec = train_samples / epoch_time if epoch_time > 0 else 0
                
                # 计算已用时间和剩余时间
                elapsed_time = time.time() - start_time
                avg_epoch_time = sum(epoch_times) / len(epoch_times)
                remaining_epochs = self.max_epochs - (epoch + 1)
                eta_seconds = avg_epoch_time * remaining_epochs
                
                # 格式化时间
                elapsed_str = self._format_time(elapsed_time)
                eta_str = self._format_time(eta_seconds)
                
                # 日志
                logger.info(
                    f"Epoch {epoch+1}/{self.max_epochs} | "
                    f"Loss: {train_metrics['loss']:.4f} | "
                    f"Val IC: {val_metrics['ic']:.4f} | "
                    f"Speed: {samples_per_sec:.0f} samples/s | "
                    f"Time: {epoch_time:.1f}s | "
                    f"Elapsed: {elapsed_str} | "
                    f"ETA: {eta_str}"
                )
                
                # 检查是否为最佳模型
                if val_metrics['ic'] > self.best_ic:
                    if val_metrics['ic'] > Config.SOTA_MIN_IC_SAVE:
                        self.best_ic = val_metrics['ic']
                        self.best_epoch = epoch
                        self.save_checkpoint('best_model.pth')
                        logger.info(f"New best model saved! IC: {self.best_ic:.4f}")
                    self.bad_epoch_count = 0
                else:
                    self.bad_epoch_count += 1
                
                # 检查熔断条件
                if val_metrics['ic'] < Config.SOTA_MIN_IC:
                    self.bad_epoch_count += 1
                    logger.warning(f"Low IC warning: {val_metrics['ic']:.4f} < {Config.SOTA_MIN_IC}")
                
                if self.bad_epoch_count >= Config.BAD_EPOCH_LIMIT:
                    raise StopTrainingError(
                        f"Training stopped: IC too low for {self.bad_epoch_count} epochs"
                    )
                
                # 早停检查 - 更严格的早停逻辑
                if self.bad_epoch_count >= self.patience:
                    logger.info(f"Early stopping at epoch {epoch+1}, bad_epoch_count: {self.bad_epoch_count}")
                    break
                
                # 额外的早停条件：如果当前IC比最佳IC低很多，提前终止
                if self.best_ic > 0.05 and (self.best_ic - val_metrics['ic']) > 0.03:
                    logger.warning(f"IC dropped significantly: {val_metrics['ic']:.4f} < best_ic - 0.03, stopping early")
                    break
                
                # Epoch 回调 - 传递额外的时间信息
                if self.callbacks['on_epoch_end']:
                    self.callbacks['on_epoch_end'](
                        epoch,
                        train_metrics,
                        val_metrics,
                        current_lr,
                        {
                            'epoch_time': epoch_time,
                            'samples_per_sec': samples_per_sec,
                            'elapsed': elapsed_time,
                            'elapsed_str': elapsed_str,
                            'eta': eta_seconds,
                            'eta_str': eta_str
                        }
                    )
        
        except StopTrainingError as e:
            logger.error(str(e))
        
        # 训练结束
        total_time = time.time() - start_time
        logger.info(f"Training completed in {self._format_time(total_time)}")
        logger.info(f"Best IC: {self.best_ic:.4f} at epoch {self.best_epoch+1}")
        
        # 训练结束回调
        if self.callbacks['on_train_end']:
            self.callbacks['on_train_end'](self.history)
        
        return self.history
    
    def _format_time(self, seconds: float) -> str:
        """格式化时间"""
        if seconds < 60:
            return f"{seconds:.0f}s"
        elif seconds < 3600:
            mins = int(seconds // 60)
            secs = int(seconds % 60)
            return f"{mins}m {secs}s"
        else:
            hours = int(seconds // 3600)
            mins = int((seconds % 3600) // 60)
            return f"{hours}h {mins}m"
    
    def save_checkpoint(self, filename: str = 'checkpoint.pth'):
        """保存检查点"""
        save_path = Config.MODEL_DIR / filename
        save_path.parent.mkdir(parents=True, exist_ok=True)
        
        checkpoint = {
            'epoch': self.current_epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'best_ic': self.best_ic,
            'history': self.history
        }
        
        torch.save(checkpoint, save_path)
        logger.info(f"Checkpoint saved to {save_path}")
    
    def load_checkpoint(self, filename: str = 'checkpoint.pth'):
        """加载检查点"""
        load_path = Config.MODEL_DIR / filename
        
        if not load_path.exists():
            logger.warning(f"Checkpoint not found: {load_path}")
            return
        
        checkpoint = torch.load(load_path)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        self.best_ic = checkpoint['best_ic']
        self.best_epoch = checkpoint['epoch']
        self.history = checkpoint['history']
        
        logger.info(f"Checkpoint loaded from {load_path}")
    
    def stop(self):
        """停止训练"""
        self._stop_flag = True
        logger.info("Training stop flag set")
