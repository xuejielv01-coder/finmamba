# -*- coding: utf-8 -*-
"""
高性能数据集 - 完全重写版
使用 numpy memmap 和预计算索引
"""

import numpy as np
import pandas as pd
from pathlib import Path
from typing import Tuple, Optional, List
import torch
from torch.utils.data import Dataset, DataLoader
import pickle

import sys
if str(Path(__file__).parent.parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).parent.parent))

from config.config import Config
from utils.logger import get_logger
from data.preprocessor import Preprocessor

logger = get_logger("Dataset")


class FastAlphaDataset(Dataset):
    """
    高性能 Alpha 数据集 - 完全优化版
    
    关键优化:
    1. 预计算所有样本索引到 numpy 数组
    2. 使用连续内存存储
    3. 避免所有 pandas 操作
    4. 零拷贝数据访问
    """
    
    def __init__(
        self,
        mode: str = 'train',
        train_ratio: float = 0.5,
        val_ratio: float = 0.3,
        force_rebuild: bool = False,
        cache_dir: Path = None
    ):
        """
        初始化数据集
        
        Args:
            mode: 'train', 'val', 或 'test'
            train_ratio: 训练集比例
            val_ratio: 验证集比例
            force_rebuild: 是否强制重建缓存
            cache_dir: 自定义缓存目录（可选）
        """
        self.mode = mode
        self.seq_len = Config.SEQ_LEN
        self.feature_cols = Preprocessor.FEATURES
        self.n_features = len(self.feature_cols)
        # 添加数据增强标志
        self.use_data_augmentation = mode == 'train'
        
        # 缓存文件路径
        if cache_dir is None:
            cache_dir = Config.DATA_ROOT / 'fast_cache'
        
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_file = self.cache_dir / f'{mode}_cache.pkl'  # 保留用于兼容
        
        # 检查 numpy 缓存文件是否存在
        features_file = self.cache_dir / f'{mode}_features.npy'
        labels_file = self.cache_dir / f'{mode}_labels.npy'
        industry_file = self.cache_dir / f'{mode}_industry.npy'  # 行业代码文件
        samples_file = self.cache_dir / f'{mode}_samples.pkl'
        cache_exists = features_file.exists() and labels_file.exists() and samples_file.exists()
        
        # 尝试加载缓存
        if not force_rebuild and cache_exists:
            logger.info(f"Loading cached dataset for {mode}...")
            self._load_cache()
        else:
            logger.info(f"Building fast dataset for {mode}...")
            self._build_dataset(train_ratio, val_ratio)
            self._save_cache()
        
        logger.info(f"FastAlphaDataset [{mode}]: {len(self.samples)} samples")
    
    @staticmethod
    def get_stock_industry_map() -> dict:
        """Load stock code to industry ID mapping from stock_basic.parquet.

        Returns:
            dict: Mapping from ts_code (str) to industry ID (int). Missing or unknown industries map to 0.
        """
        stock_basic_path = Config.DATA_ROOT / 'stock_basic.parquet'
        if not stock_basic_path.exists():
            logger.warning(f"stock_basic.parquet not found at {stock_basic_path}, returning empty industry map")
            return {}
        try:
            df = pd.read_parquet(stock_basic_path, columns=['ts_code', 'industry'])
        except Exception as e:
            logger.error(f"Failed to read stock_basic.parquet: {e}")
            return {}
        unique_inds = df['industry'].dropna().unique()
        ind_name_to_id = {name: idx + 1 for idx, name in enumerate(sorted(unique_inds))}
        industry_map = {}
        for _, row in df.iterrows():
            ts_code = row['ts_code']
            ind_name = row['industry']
            if pd.isna(ind_name):
                industry_map[ts_code] = 0
            else:
                industry_map[ts_code] = ind_name_to_id.get(ind_name, 0)
        return industry_map
    
    def _build_dataset(self, train_ratio: float, val_ratio: float):
        """构建数据集 - 使用分块读取避免内存溢出"""
        import gc
        from datetime import datetime, timedelta
        
        # 加载原始数据
        data_path = Config.PROCESSED_DATA_DIR / "all_features.parquet"
        if not data_path.exists():
            logger.error("Processed data not found")
            self.samples = []
            self.features = np.array([])
            self.labels = np.array([])
            self.industry_ids = np.array([], dtype=np.int64)
            return
        
        # 先读取日期列，进行时间划分
        logger.info("Reading date information...")
        df_dates = pd.read_parquet(data_path, columns=['trade_date'])
        df_dates['trade_date'] = pd.to_datetime(df_dates['trade_date'])
        
        all_dates = sorted(df_dates['trade_date'].unique())
        
        # ============ 明确的日期划分 ============
        # 训练集: 数据开始 ~ 2024年6月30日
        # 验证集: 2024年7月1日 ~ 2025年6月30日
        # 测试集: 2025年7月1日 ~ 当前
        
        train_end_date = datetime(2024, 6, 30)
        val_start_date = datetime(2024, 7, 1)
        val_end_date = datetime(2025, 6, 30)
        test_start_date = datetime(2025, 7, 1)
        
        # 计算训练数据开始日期: 使用 TRAIN_YEARS 配置
        if hasattr(Config, 'TRAIN_YEARS') and Config.TRAIN_YEARS > 0:
            train_start_date = train_end_date - timedelta(days=Config.TRAIN_YEARS * 365)
        else:
            train_start_date = train_end_date - timedelta(days=Config.TRAIN_START_YEARS * 365)
        
        # 根据模式选择日期范围
        if self.mode == 'train':
            date_range = [d for d in all_dates if train_start_date <= d <= train_end_date]
        elif self.mode == 'val':
            date_range = [d for d in all_dates if val_start_date <= d <= val_end_date]
        else:  # test
            date_range = [d for d in all_dates if d >= test_start_date]
        
        # 确保日期范围有效
        if len(date_range) == 0:
            logger.error(f"No dates found for {self.mode} mode!")
            raise ValueError(f"No dates found for {self.mode} mode")
        
        # 清晰的日志输出
        logger.info(f"=== {self.mode.upper()} Dataset ===")
        logger.info(f"  Date range: {date_range[0].strftime('%Y-%m-%d')} to {date_range[-1].strftime('%Y-%m-%d')}")
        logger.info(f"  Total trading days: {len(date_range)}")
        
        # 显示完整的划分信息 (仅在 train 模式显示一次)
        if self.mode == 'train':
            logger.info(f"--- Data Split Plan ---")
            logger.info(f"  Train: {train_start_date.strftime('%Y-%m-%d')} ~ {train_end_date.strftime('%Y-%m-%d')}")
            logger.info(f"  Val:   {val_start_date.strftime('%Y-%m-%d')} ~ {val_end_date.strftime('%Y-%m-%d')}")
            logger.info(f"  Test:  {test_start_date.strftime('%Y-%m-%d')} ~ now")
        
        # 分块读取数据
        chunk_size = 10000  # 每次读取 10000 只股票
        features_list = []
        labels_list = []
        industry_list = []  # 行业代码列表
        samples = []
        
        # 行业代码映射 (股票代码 -> 行业ID)
        industry_map = self.get_stock_industry_map()
        
        # 获取所有股票代码 (如果map中没有，使用默认值)
        all_ts_codes = pd.read_parquet(data_path, columns=['ts_code'])['ts_code'].unique()
        n_stocks = len(all_ts_codes)
        
        # 补全缺失的映射 (默认行业ID=0)
        for ts_code in all_ts_codes:
            if ts_code not in industry_map:
                industry_map[ts_code] = 0
                
        logger.info(f"Industry map ready for {len(industry_map)} stocks")
        
        logger.info(f"Processing {n_stocks} stocks in chunks...")
        
        # 滑动窗口参数 - 所有数据集都使用步长=1，最大化样本量
        use_sliding_window = True
        slide_step = 1
        
        logger.info(f"Using sliding window: {use_sliding_window}, slide_step: {slide_step}")
        
        for batch_idx in range(0, n_stocks, chunk_size):
            ts_codes_batch = all_ts_codes[batch_idx:batch_idx + chunk_size]
            
            # 读取该批次的数据
            df_batch = pd.read_parquet(
                data_path,
                filters=[('ts_code', 'in', ts_codes_batch)]
            )
            
            # 过滤日期
            df_batch = df_batch[df_batch['trade_date'].isin(date_range)].copy()
            
            if len(df_batch) == 0:
                continue
            
            # 计算 ret_rank：每日截面排名 (使用 ret_1d 收益率的排序分数)
            # 如果 ret_1d 不存在，使用 pct_chg 或 close 变化率
            if 'ret_1d' not in df_batch.columns:
                if 'pct_chg' in df_batch.columns:
                    df_batch['ret_1d'] = df_batch['pct_chg']
                elif 'close' in df_batch.columns:
                    df_batch['ret_1d'] = df_batch.groupby('ts_code')['close'].pct_change() * 100
                else:
                    df_batch['ret_1d'] = 0
            
            # 计算每日的截面排名 (rank / count, 归一化到 [0, 1])
            df_batch['ret_rank'] = df_batch.groupby('trade_date')['ret_1d'].rank(pct=True, method='average')
            df_batch['ret_rank'] = df_batch['ret_rank'].fillna(0.5)  # 缺失值设为中位数
            
            # 按股票分组
            for ts_code, group in df_batch.groupby('ts_code'):
                group = group.sort_values('trade_date').reset_index(drop=True)
                n_rows = len(group)
                
                if n_rows < self.seq_len:
                    continue
                
                # 提取特征矩阵
                feature_matrix = group[self.feature_cols].values.astype(np.float32)
                labels = group['ret_rank'].values.astype(np.float32)
                
                # 创建样本索引 - 使用滑动窗口
                if use_sliding_window:
                    # 滑动窗口方式：增加训练数据量，提高泛化能力
                    for i in range(self.seq_len - 1, n_rows, slide_step):
                        # 滑动窗口结束位置
                        end_idx = i + 1
                        # 窗口开始位置
                        start_idx = end_idx - self.seq_len
                        
                        # 确保窗口长度正确
                        if end_idx - start_idx != self.seq_len:
                            continue
                        
                        # 提取序列
                        seq = feature_matrix[start_idx:end_idx]  # (seq_len, n_features)
                        label = labels[i]
                        
                        # 获取行业ID
                        prefix = ts_code[:2]
                        ind_id = industry_map.get(prefix, 0)
                        
                        features_list.append(seq)
                        labels_list.append(label)
                        industry_list.append(ind_id)
                        samples.append((ts_code, i))
                else:
                    # 传统方式：每个样本对应一个时间点
                    for i in range(self.seq_len - 1, n_rows):
                        start_idx = i - self.seq_len + 1
                        
                        # 提取序列
                        seq = feature_matrix[start_idx:i+1]  # (seq_len, n_features)
                        label = labels[i]
                        
                        # 获取行业ID
                        ind_id = industry_map.get(ts_code, 0)
                        
                        features_list.append(seq)
                        labels_list.append(label)
                        industry_list.append(ind_id)
                        samples.append((ts_code, i))
            
            # 清理内存
            del df_batch
            gc.collect()
            
            if (batch_idx + 1) % 10 == 0:
                logger.info(f"Processed {batch_idx + 1} batches, {len(samples)} samples so far...")
        
        # 转换为连续数组
        if len(features_list) > 0:
            self.features = np.array(features_list, dtype=np.float32)  # (N, seq_len, n_features)
            self.labels = np.array(labels_list, dtype=np.float32)  # (N,)
            self.industry_ids = np.array(industry_list, dtype=np.int64)  # (N,) 行业ID
            self.samples = samples
        else:
            self.features = np.array([], dtype=np.float32)
            self.labels = np.array([], dtype=np.float32)
            self.industry_ids = np.array([], dtype=np.int64)
            self.samples = []
        
        logger.info(f"Built {len(self.samples)} samples, features shape: {self.features.shape}")
    
    def _save_cache(self):
        """保存缓存 - 使用 numpy 格式避免内存问题"""
        try:
            # 保存为 numpy 文件（更高效）
            cache_dir = self.cache_file.parent
            cache_dir.mkdir(parents=True, exist_ok=True)
            
            # Helper to safely save numpy file
            def safe_save(path, arr):
                if path.exists():
                    try:
                        path.unlink()  # Try to delete existing file first
                    except Exception:
                        pass  # If delete fails (e.g. locked), try saving anyway (might fail)
                np.save(path, arr)

            safe_save(cache_dir / f'{self.mode}_features.npy', self.features)
            safe_save(cache_dir / f'{self.mode}_labels.npy', self.labels)
            safe_save(cache_dir / f'{self.mode}_industry.npy', self.industry_ids)
            
            # 保存样本索引（小文件，用 pickle）
            with open(cache_dir / f'{self.mode}_samples.pkl', 'wb') as f:
                pickle.dump(self.samples, f)
            
            logger.info(f"Saved cache to {cache_dir}")
        except Exception as e:
            logger.warning(f"Failed to save cache: {e}")
    
    def _load_cache(self):
        """加载缓存 - 使用 numpy 格式"""
        try:
            cache_dir = self.cache_file.parent
            
            # 使用 mmap_mode='r' 进行内存映射（不占用内存）
            self.features = np.load(
                cache_dir / f'{self.mode}_features.npy',
                mmap_mode='r'  # 内存映射，不加载到内存
            )
            # labels 也使用 mmap_mode='r'（减少内存占用）
            self.labels = np.load(
                cache_dir / f'{self.mode}_labels.npy',
                mmap_mode='r'  # 内存映射，不加载到内存
            )
            
            # 加载行业ID (如果存在)
            industry_file = cache_dir / f'{self.mode}_industry.npy'
            if industry_file.exists():
                self.industry_ids = np.load(industry_file, mmap_mode='r')
            else:
                # 兼容旧缓存：生成默认行业ID
                self.industry_ids = np.zeros(len(self.labels), dtype=np.int64)
                logger.warning("Industry IDs not found in cache, using default (0)")
            
            with open(cache_dir / f'{self.mode}_samples.pkl', 'rb') as f:
                self.samples = pickle.load(f)
            
            logger.info(f"Loaded cache from {cache_dir} (mmap mode)")
        except Exception as e:
            logger.error(f"Failed to load cache: {e}")
            raise
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, dict]:
        """
        获取单个样本 - 包含行业ID
        
        从预计算的 numpy 数组读取（支持 mmap）
        
        Returns:
            X: (seq_len, n_features) 特征序列
            y: () 标签
            industry_id: () 行业ID
            info: 元数据字典
        """
        # 从 mmap 数组读取（使用 ascontiguousarray 优化）
        features = np.ascontiguousarray(self.features[idx])  # 优化内存布局
        label = np.ascontiguousarray(self.labels[idx])  # 优化内存布局
        industry_id = int(self.industry_ids[idx])  # 行业ID
        
        # 数据增强（仅训练集）
        if self.use_data_augmentation:
            # 1. 添加少量随机噪声
            noise = np.random.normal(0, 0.02, features.shape)
            features = features + noise
            
            # 2. 随机缩放（±5%）
            scale = np.random.uniform(0.95, 1.05)
            features = features * scale
            
            # 3. 时间序列平移（±1步）
            if np.random.random() < 0.2:
                shift = np.random.choice([-1, 1])
                features = np.roll(features, shift, axis=0)
                # 填充缺失值
                if shift > 0:
                    features[:shift] = 0
                else:
                    features[shift:] = 0
            
            # 4. 随机翻转（时间轴）
            if np.random.random() < 0.1:
                features = np.flip(features, axis=0)
            
            # 5. 随机缺失（随机遮盖一些特征值）
            if np.random.random() < 0.2:
                mask = np.random.random(features.shape) < 0.05
                features[mask] = 0
            
            # 6. 随机交换特征（特征维度）
            if np.random.random() < 0.1:
                # 随机选择两个特征进行交换
                if features.shape[1] > 1:
                    idx1, idx2 = np.random.choice(features.shape[1], 2, replace=False)
                    features[:, [idx1, idx2]] = features[:, [idx2, idx1]]
        
        # 转换为 tensor，显式转换为 float32 以匹配模型权重类型
        X = torch.from_numpy(features.copy()).float()  # 转换为 float32，避免Double类型
        y = torch.tensor(label, dtype=torch.float32)
        ind = torch.tensor(industry_id, dtype=torch.long)  # 行业ID
        
        ts_code, _ = self.samples[idx]
        info = {'ts_code': ts_code, 'date': '', 'future_ret': 0.0}
        
        return X, y, ind, info


class AlphaDataModule:
    """
    数据模块管理器 - 优化版
    """
    
    def __init__(
        self,
        data: pd.DataFrame = None,
        batch_size: int = None,
        num_workers: int = None,
        force_rebuild: bool = False,
        auto_clear_cache: bool = True,  # 新增：自动清除缓存
        **kwargs
    ):
        """
        初始化数据模块
        
        Args:
            data: 输入数据（忽略，使用缓存）
            batch_size: 批次大小
            num_workers: 数据加载线程数
            force_rebuild: 是否强制重建缓存
            auto_clear_cache: 是否自动清除缓存（默认True）
        """
        self.batch_size = batch_size or Config.BATCH_SIZE
        self.num_workers = num_workers
        self.force_rebuild = force_rebuild
        
        # 自动清除缓存，确保每次训练使用最新数据
        # 使用基于时间戳的会话目录，彻底解决 Windows 文件锁定问题
        self.session_cache_dir = None
        if auto_clear_cache:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.session_cache_dir = Config.DATA_ROOT / 'fast_cache' / timestamp
            self._clear_old_caches() # 尝试清理旧缓存
            force_rebuild = True
        
        # 创建数据集
        self.train_dataset = FastAlphaDataset(mode='train', force_rebuild=force_rebuild, cache_dir=self.session_cache_dir)
        self.val_dataset = FastAlphaDataset(mode='val', force_rebuild=force_rebuild, cache_dir=self.session_cache_dir)
        self.test_dataset = FastAlphaDataset(mode='test', force_rebuild=force_rebuild, cache_dir=self.session_cache_dir)
    
    def _clear_old_caches(self):
        """尝试清理旧的缓存目录"""
        import shutil
        import time
        root_cache_dir = Config.DATA_ROOT / 'fast_cache'
        if not root_cache_dir.exists():
            return
            
        try:
            # 清理超过 24 小时的旧目录
            current_time = time.time()
            for path in root_cache_dir.iterdir():
                if path.is_dir():
                    try:
                        # 如果目录名是日期格式，或者修改时间很久以前
                        stat = path.stat()
                        if current_time - stat.st_mtime > 3600: # 1小时前的都可以清理
                            shutil.rmtree(path)
                            logger.info(f"Cleaned up old cache: {path}")
                    except Exception:
                        pass # 忽略清理失败（可能被占用）
        except Exception:
            pass

    def _clear_cache(self):
        """已弃用 - 由 session_cache_dir 替代"""
        pass
    
    def train_dataloader(self) -> DataLoader:
        """训练数据加载器 - 超优化版"""
        import os
        import multiprocessing
        
        # 优化 num_workers：根据 CPU 核心数动态调整
        # 13代 i5 通常是 6 核 12 线程
        if self.num_workers is None:
            if os.name == 'nt':  # Windows
                # Windows 下使用 0 workers（避免内存复制问题）
                # Windows 下每个 worker 进程都会复制数据集到内存中
                self.num_workers = 0
            else:  # Linux/Mac
                # Linux 下可以使用更多 workers
                cpu_count = multiprocessing.cpu_count() or 6
                self.num_workers = min(8, cpu_count)
        
        logger.info(f"Train dataloader: num_workers={self.num_workers}, batch_size={self.batch_size}")
        
        # Windows 下禁用 persistent_workers（避免 pickle 问题）
        persistent_workers = False if os.name == 'nt' else True
        
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=True,
            drop_last=True,
            persistent_workers=persistent_workers,  # Windows 下禁用
            prefetch_factor=2 if persistent_workers else None,  # Windows 下禁用
            # Windows 下需要设置 spawn_start_method
        )
    
    def val_dataloader(self) -> DataLoader:
        """验证数据加载器"""
        import os
        import multiprocessing
        
        # 验证集使用较少的 workers
        if self.num_workers is None:
            if os.name == 'nt':  # Windows
                # Windows 下使用 0 workers（避免内存复制问题）
                self.num_workers = 0
            else:  # Linux/Mac
                cpu_count = multiprocessing.cpu_count() or 6
                self.num_workers = min(6, cpu_count)
        
        logger.info(f"Val dataloader: num_workers={self.num_workers}, batch_size={self.batch_size}")
        
        # Windows 下禁用 persistent_workers（避免 pickle 问题）
        persistent_workers = False if os.name == 'nt' else True
        
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=True,
            persistent_workers=persistent_workers,  # Windows 下禁用
            prefetch_factor=2 if persistent_workers else None,  # Windows 下禁用
        )
    
    def test_dataloader(self) -> DataLoader:
        """测试数据加载器"""
        import os
        import multiprocessing
        
        # 测试集使用较少的 workers
        if self.num_workers is None:
            if os.name == 'nt':  # Windows
                # Windows 下使用 0 workers（避免内存复制问题）
                self.num_workers = 0
            else:  # Linux/Mac
                cpu_count = multiprocessing.cpu_count() or 6
                self.num_workers = min(6, cpu_count)
        
        logger.info(f"Test dataloader: num_workers={self.num_workers}, batch_size={self.batch_size}")
        
        # Windows 下禁用 persistent_workers（避免 pickle 问题）
        persistent_workers = False if os.name == 'nt' else True
        
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=True,
            persistent_workers=persistent_workers,  # Windows 下禁用
            prefetch_factor=2 if persistent_workers else None,  # Windows 下禁用
        )
    
    @staticmethod
    def _collate_fn(batch):
        """自定义 collate 函数 - 包含行业ID"""
        X_list, y_list, ind_list, info_list = zip(*batch)
        X = torch.stack(X_list)
        y = torch.stack(y_list)
        ind = torch.stack(ind_list)
        return X, y, ind, info_list


# 向后兼容
AlphaDataset = FastAlphaDataset


def create_dataloaders(
    data: pd.DataFrame = None,
    batch_size: int = None,
    force_rebuild: bool = False
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    便捷函数: 创建数据加载器
    
    Returns:
        (train_loader, val_loader, test_loader)
    """
    data_module = AlphaDataModule(data, batch_size, force_rebuild=force_rebuild)
    return (
        data_module.train_dataloader(),
        data_module.val_dataloader(),
        data_module.test_dataloader()
    )
