# -*- coding: utf-8 -*-
from .trainer import Trainer, StopTrainingError

__all__ = ['Trainer', 'StopTrainingError']
