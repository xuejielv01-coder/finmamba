# -*- coding: utf-8 -*-
"""
损失函数模块

包含:
- MSELoss: 预测误差
- RankLoss: 排序损失
- CombinedLoss: 组合损失
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class RankLoss(nn.Module):
    """
    排序损失 (Pairwise Ranking Loss)
    
    优化目标: 正确排序股票收益
    """
    
    def __init__(self, margin: float = 0.0):
        super().__init__()
        self.margin = margin
    
    def forward(
        self, 
        pred: torch.Tensor, 
        target: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            pred: (B, 1) 预测分数
            target: (B,) 真实标签 (排名或收益)
        
        Returns:
            Ranking loss
        """
        pred = pred.squeeze()
        target = target.squeeze()
        
        B = pred.size(0)
        if B < 2:
            return torch.tensor(0.0, device=pred.device)
        
        # 创建配对比较
        # diff_pred[i, j] = pred[i] - pred[j]
        diff_pred = pred.unsqueeze(1) - pred.unsqueeze(0)  # (B, B)
        diff_target = target.unsqueeze(1) - target.unsqueeze(0)  # (B, B)
        
        # 符号比较: target_i > target_j 时，应有 pred_i > pred_j
        sign = torch.sign(diff_target)  # (B, B)
        
        # Hinge loss: max(0, margin - sign * diff_pred)
        loss = F.relu(self.margin - sign * diff_pred)
        
        # 只计算上三角 (避免重复)
        mask = torch.triu(torch.ones(B, B, device=pred.device), diagonal=1).bool()
        loss = loss[mask].mean()
        
        return loss


class ICLoss(nn.Module):
    """
    IC (Information Coefficient) 损失
    
    最大化预测与真实值的相关性
    """
    
    def __init__(self):
        super().__init__()
    
    def forward(
        self, 
        pred: torch.Tensor, 
        target: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            pred: (B, 1) 预测分数
            target: (B,) 真实标签
        
        Returns:
            -IC (负相关系数，用于最小化)
        """
        pred = pred.squeeze()
        target = target.squeeze()
        
        # 标准化
        pred_mean = pred.mean()
        target_mean = target.mean()
        pred_std = pred.std() + 1e-8
        target_std = target.std() + 1e-8
        
        pred_norm = (pred - pred_mean) / pred_std
        target_norm = (target - target_mean) / target_std
        
        # 皮尔逊相关系数
        ic = (pred_norm * target_norm).mean()
        
        # 返回负值 (最小化损失 = 最大化 IC)
        return -ic


class CombinedLoss(nn.Module):
    """
    组合损失函数
    
    结合 MSE 和 RankLoss
    """
    
    def __init__(
        self,
        mse_weight: float = 1.0,
        rank_weight: float = 1.0,
        ic_weight: float = 0.5
    ):
        super().__init__()
        self.mse_weight = mse_weight
        self.rank_weight = rank_weight
        self.ic_weight = ic_weight
        
        self.mse_loss = nn.MSELoss()
        self.rank_loss = RankLoss()
        self.ic_loss = ICLoss()
    
    def forward(
        self, 
        pred: torch.Tensor, 
        target: torch.Tensor
    ) -> tuple:
        """
        Args:
            pred: (B, 1) 预测分数
            target: (B,) 真实标签
        
        Returns:
            (total_loss, loss_dict)
        """
        pred = pred.squeeze()
        target = target.squeeze()
        
        # 各项损失
        mse = self.mse_loss(pred, target)
        rank = self.rank_loss(pred, target)
        ic = self.ic_loss(pred, target)
        
        # 加权组合
        total = (
            self.mse_weight * mse +
            self.rank_weight * rank +
            self.ic_weight * ic
        )
        
        loss_dict = {
            'total': total.item(),
            'mse': mse.item(),
            'rank': rank.item(),
            'ic': -ic.item()  # 返回正 IC 值
        }
        
        return total, loss_dict


def calculate_ic(pred: torch.Tensor, target: torch.Tensor) -> float:
    """
    计算 IC (Information Coefficient)
    
    Args:
        pred: 预测值
        target: 真实值
    
    Returns:
        IC 值
    """
    pred = pred.detach().cpu().numpy().flatten()
    target = target.detach().cpu().numpy().flatten()
    
    from scipy.stats import pearsonr
    try:
        ic, _ = pearsonr(pred, target)
        return ic if not np.isnan(ic) else 0.0
    except:
        return 0.0


def calculate_rank_ic(pred: torch.Tensor, target: torch.Tensor) -> float:
    """
    计算 RankIC (Spearman Correlation)
    
    Args:
        pred: 预测值
        target: 真实值
    
    Returns:
        RankIC 值
    """
    pred = pred.detach().cpu().numpy().flatten()
    target = target.detach().cpu().numpy().flatten()
    
    from scipy.stats import spearmanr
    import numpy as np
    try:
        rank_ic, _ = spearmanr(pred, target)
        return rank_ic if not np.isnan(rank_ic) else 0.0
    except:
        return 0.0


import numpy as np
