# -*- coding: utf-8 -*-
"""
智能下载器 (TushareDownloader)
PRD 2.1 实现
"""

import os
import json
import time
import threading
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Callable
import pandas as pd

try:
    import tushare as ts
except ImportError:
    ts = None

from config.config import Config
from utils.logger import get_logger
from utils.tools import rate_limit, retry, is_main_board

logger = get_logger("Downloader")

class TushareDownloader:
    """
    Tushare 数据下载器

    特性:
    - API 限流 (0.8s 间隔)
    - 原子化写入 (temp -> rename)
    - 断点续传 (manifest.json)
    - 增量下载
    """

    def __init__(self, token: str = None):
        """初始化下载器

        Args:
            token: Tushare API Token
        """
        self.token = token or Config.TUSHARE_TOKEN

        if ts is None:
            raise ImportError("Please install tushare: pip install tushare")

        # 初始化 API
        ts.set_token(self.token)
        self.api = ts.pro_api()

        # 确保目录存在
        Config.ensure_dirs()

        # 加载 manifest
        self.manifest = self._load_manifest()

        # 信号量控制并发
        self._semaphore = threading.Semaphore(1)

        # 最后请求时间 (限流用)
        self._last_request_time = 0.0
        # Increase to 800ms to be safe (max ~75 req/min)
        self._rate_limit_interval = 0.8

        # 进度回调
        self.progress_callback: Optional[Callable[[int, int, str], None]] = None

        # 停止标志
        self._stop_flag = False

        logger.info("TushareDownloader initialized")

    def _load_manifest(self) -> Dict:
        """加载下载清单"""
        manifest_file = Config.MANIFEST_FILE
        if manifest_file.exists():
            with open(manifest_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def _save_manifest(self):
        """保存下载清单"""
        manifest_file = Config.MANIFEST_FILE
        with open(manifest_file, "w", encoding="utf-8") as f:
            json.dump(self.manifest, f, ensure_ascii=False, indent=2)

    def _rate_limit_check(self):
        """限流检查"""
        elapsed = time.time() - self._last_request_time
        if elapsed < self._rate_limit_interval:
            time.sleep(self._rate_limit_interval - elapsed)
        self._last_request_time = time.time()

    @retry(max_retries=5, delay=5.0)
    def _api_call(self, method: str, **kwargs) -> Optional[pd.DataFrame]:
        """带重试的 API 调用 (增强版)"""
        with self._semaphore:
            self._rate_limit_check()
            try:
                func = getattr(self.api, method)
                df = func(**kwargs)
                return df
            except Exception as e:
                error_msg = str(e).lower()
                # 检查是否为限流错误
                if "limit" in error_msg or "exceed" in error_msg or "频率" in error_msg or "抱歉" in error_msg:
                    logger.warning(f"API Rate limit hit ({method}): {e}. Sleeping for 60s...")
                    time.sleep(60)
                    # 抛出异常以触发 retry
                    raise e
                logger.error(f"API call failed: {method}, error: {e}")
                raise

    def get_main_board_stocks(self) -> pd.DataFrame:
        """获取主板股票列表"""
        logger.info("Fetching main board stock list...")
        df = self._api_call('stock_basic',
                           exchange='',
                           list_status='L',
                           fields='ts_code,symbol,name,area,industry,market,list_date')
        if df is None or df.empty:
            logger.warning("No stock data returned")
            return pd.DataFrame()
        # 主板过滤 (60/00 开头)
        df = df[df['ts_code'].str.match(r'^(60|00)')]
        # ST 过滤
        if Config.DROP_ST:
            df = df[~df['name'].str.contains('ST', case=False, na=False)]
        logger.info(f"Found {len(df)} main board stocks")
        return df

    def _atomic_write(self, df: pd.DataFrame, filepath: Path):
        """原子化写入 Parquet 文件"""
        temp_file = filepath.with_suffix('.temp.parquet')
        try:
            df.to_parquet(temp_file, index=False)
            if filepath.exists():
                filepath.unlink()
            os.rename(temp_file, filepath)
        except Exception as e:
            if temp_file.exists():
                temp_file.unlink()
            raise e

    def download_stock_data(
        self,
        ts_code: str,
        start_date: str = None,
        end_date: str = None
    ) -> Optional[pd.DataFrame]:
        """下载单只股票的全部数据"""
        if end_date is None:
            end_date = datetime.now().strftime('%Y%m%d')
        if start_date is None:
            start_date = (datetime.now() - timedelta(days=365*Config.DOWNLOAD_YEARS)).strftime('%Y%m%d')
        logger.info(f"Downloading data for {ts_code}: {start_date} to {end_date}")
        try:
            daily = self._api_call('daily', ts_code=ts_code, start_date=start_date, end_date=end_date)
            if daily is None or daily.empty:
                logger.warning(f"{ts_code}: No daily data")
                return None
            adj = self._api_call('adj_factor', ts_code=ts_code, start_date=start_date, end_date=end_date)
            basic = self._api_call('daily_basic', ts_code=ts_code, start_date=start_date, end_date=end_date,
                                   fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb,ps,total_mv,circ_mv')
            try:
                moneyflow = self._api_call('moneyflow', ts_code=ts_code, start_date=start_date, end_date=end_date)
            except Exception:
                moneyflow = None
                logger.warning(f"{ts_code}: No moneyflow data (permission denied?)")
            df = daily
            if adj is not None and not adj.empty:
                df = df.merge(adj[['trade_date', 'adj_factor']], on='trade_date', how='left')
            if basic is not None and not basic.empty:
                df = df.merge(basic, on=['ts_code', 'trade_date'], how='left')
            if moneyflow is not None and not moneyflow.empty:
                mf_cols = ['trade_date', 'buy_sm_vol', 'sell_sm_vol', 'buy_sm_amount', 'sell_sm_amount',
                           'buy_md_vol', 'sell_md_vol', 'buy_md_amount', 'sell_md_amount',
                           'buy_lg_vol', 'sell_lg_vol', 'buy_lg_amount', 'sell_lg_amount',
                           'buy_elg_vol', 'sell_elg_vol', 'buy_elg_amount', 'sell_elg_amount',
                           'net_mf_vol', 'net_mf_amount']
                mf_cols = [c for c in mf_cols if c in moneyflow.columns]
                df = df.merge(moneyflow[mf_cols], on='trade_date', how='left')
            df = df.sort_values('trade_date').reset_index(drop=True)
            return df
        except Exception as e:
            logger.error(f"{ts_code}: Download failed - {e}")
            return None

    def download_all(
        self,
        stock_list: List[str] = None,
        force_update: bool = False
    ):
        """批量下载所有股票数据"""
        if stock_list is None:
            stocks_df = self.get_main_board_stocks()
            stock_list = stocks_df['ts_code'].tolist()
        total = len(stock_list)
        logger.info(f"Starting download: {total} stocks")
        success_count = 0
        fail_count = 0
        for i, ts_code in enumerate(stock_list):
            if self._stop_flag:
                logger.info("Download stopped by user")
                break
            if not force_update and ts_code in self.manifest:
                manifest_end = self.manifest[ts_code].get('end_date')
                today = datetime.now().strftime('%Y%m%d')
                if manifest_end == today:
                    if self.progress_callback:
                        self.progress_callback(i + 1, total, f"{ts_code} (skipped)")
                    continue
                start_date = manifest_end
            else:
                start_date = None
            df = self.download_stock_data(ts_code, start_date=start_date)
            if df is not None and not df.empty:
                save_path = Config.RAW_DATA_DIR / f"{ts_code.replace('.', '_')}.parquet"
                if save_path.exists() and start_date is not None:
                    try:
                        old_df = pd.read_parquet(save_path)
                        df = pd.concat([old_df, df]).drop_duplicates(subset='trade_date', keep='last')
                        df = df.sort_values('trade_date').reset_index(drop=True)
                    except Exception:
                        pass
                self._atomic_write(df, save_path)
                self.manifest[ts_code] = {
                    'start_date': df['trade_date'].min(),
                    'end_date': df['trade_date'].max(),
                    'records': len(df)
                }
                success_count += 1
            else:
                fail_count += 1
            if self.progress_callback:
                self.progress_callback(i + 1, total, ts_code)
            if (i + 1) % 100 == 0:
                self._save_manifest()
                logger.info(f"Progress: {i + 1}/{total} stocks downloaded")
        self._save_manifest()
        logger.info(f"Download completed: {success_count} success, {fail_count} failed")

    def download_index_data(self, index_code: str = None) -> Optional[pd.DataFrame]:
        """下载指数数据"""
        if index_code is None:
            index_code = Config.INDEX_CODE
        end_date = datetime.now().strftime('%Y%m%d')
        start_date = (datetime.now() - timedelta(days=365)).strftime('%Y%m%d')
        try:
            df = self._api_call('index_daily', ts_code=index_code,
                               start_date=start_date, end_date=end_date)
            if df is not None and not df.empty:
                save_path = Config.RAW_DATA_DIR / f"index_{index_code.replace('.', '_')}.parquet"
                self._atomic_write(df, save_path)
                logger.info(f"Index {index_code} data saved")
            return df
        except Exception as e:
            logger.error(f"Failed to download index {index_code}: {e}")
            return None

    def stop(self):
        """停止下载"""
        self._stop_flag = True
        logger.info("Download stop requested")

    def reset(self):
        """重置停止标志"""
        self._stop_flag = False
