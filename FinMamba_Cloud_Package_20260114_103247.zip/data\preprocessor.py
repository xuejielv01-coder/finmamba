# -*- coding: utf-8 -*-
"""
特征工程核心 (Preprocessor)
PRD 2.2 实现

特性:
- 资金流因子计算
- 技术指标 (MACD, RSI, BOLL等)
- 截面统计量缓存 (Z-Score)
- 主板严格过滤
"""

import json
from pathlib import Path
from typing import Tuple, Dict, List, Optional
from datetime import datetime
import pandas as pd
import numpy as np

try:
    import pandas_ta as ta
except ImportError:
    ta = None

import sys
# 确保能导入项目模块
if str(Path(__file__).parent.parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).parent.parent))

from config.config import Config
from utils.logger import get_logger
from utils.tools import is_main_board, robust_zscore

logger = get_logger("Preprocessor")


class Preprocessor:
    """
    数据预处理器
    
    负责:
    1. 主板过滤
    2. 资金流因子计算
    3. 技术指标计算
    4. Z-Score 标准化
    5. 统计量缓存
    """
    
    # 48维特征定义
    FEATURES = [
        # 价格相关 (4)
        'open_pct', 'high_pct', 'low_pct', 'close_pct',
        # 成交量相关 (2)
        'vol_ma5_ratio', 'vol_ma10_ratio',
        # 资金流因子 (12)
        'mf_net_ratio', 'retail_sentiment', 'main_force_ratio',
        'elg_ratio', 'lg_ratio', 'md_ratio', 'sm_ratio',
        'buy_sell_ratio', 'net_mf_vol_ratio', 'net_mf_amount_ratio',
        'large_order_ratio', 'small_order_ratio',
        # 技术指标 (16)
        'rsi_6', 'rsi_12', 'rsi_24',
        'macd', 'macd_signal', 'macd_hist',
        'boll_upper_ratio', 'boll_lower_ratio', 'boll_width',
        'ma5_ratio', 'ma10_ratio', 'ma20_ratio', 'ma60_ratio',
        'atr_ratio', 'cci', 'willr',
        # 估值指标 (6)
        'pe_zscore', 'pb_zscore', 'ps_zscore',
        'turnover_rate', 'volume_ratio', 'total_mv_rank',
        # 时间特征 (4)
        'weekday', 'month', 'is_month_start', 'is_month_end',
        # 收益特征 (4)
        'ret_1d', 'ret_5d', 'ret_10d', 'ret_20d',
    ]
    
    def __init__(self):
        """初始化预处理器"""
        Config.ensure_dirs()
        self.stats_cache_dir = Config.STATS_CACHE
        logger.info("Preprocessor initialized")
    
    def process_daily_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        处理单日原始数据，计算所有特征
        
        Args:
            df: 原始日线数据 DataFrame
        
        Returns:
            处理后的 DataFrame (含48维特征)
        """
        if df.empty:
            return df
        
        df = df.copy()
        
        # 确保日期排序
        df['trade_date'] = pd.to_datetime(df['trade_date'])
        df = df.sort_values('trade_date').reset_index(drop=True)
        
        # 1. 计算价格百分比特征
        df = self._calculate_price_features(df)
        
        # 2. 计算成交量特征
        df = self._calculate_volume_features(df)
        
        # 3. 计算资金流因子
        df = self._calculate_moneyflow_features(df)
        
        # 4. 计算技术指标
        df = self._calculate_technical_indicators(df)
        
        # 5. 计算估值指标
        df = self._calculate_valuation_features(df)
        
        # 6. 计算时间特征
        df = self._calculate_time_features(df)
        
        # 7. 计算收益特征
        df = self._calculate_return_features(df)
        
        # 8. 清洗数据
        df = self._clean_data(df)
        
        return df
    
    def _calculate_price_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """计算价格相关特征"""
        # 价格变动百分比 (相对于昨收)
        prev_close = df['close'].shift(1)
        df['open_pct'] = (df['open'] / prev_close - 1) * 100
        df['high_pct'] = (df['high'] / prev_close - 1) * 100
        df['low_pct'] = (df['low'] / prev_close - 1) * 100
        df['close_pct'] = (df['close'] / prev_close - 1) * 100
        return df
    
    def _calculate_volume_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """计算成交量特征"""
        df['vol_ma5'] = df['vol'].rolling(5).mean()
        df['vol_ma10'] = df['vol'].rolling(10).mean()
        df['vol_ma5_ratio'] = df['vol'] / df['vol_ma5']
        df['vol_ma10_ratio'] = df['vol'] / df['vol_ma10']
        return df
    
    def _calculate_moneyflow_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        计算资金流因子 (PRD 2.2)
        
        核心因子:
        1. mf_net_ratio: 净资金流比率
        2. retail_sentiment: 散户情绪
        3. main_force_ratio: 主力净流入占比
        """
        # 检查是否有资金流数据
        has_mf = 'buy_elg_amount' in df.columns
        
        if has_mf:
            # 确保有金额数据
            df['amount'] = df.get('amount', df['vol'] * df['close'])
            
            # 1. 净资金流比率
            buy_total = df.get('buy_elg_amount', 0) + df.get('buy_lg_amount', 0) + \
                       df.get('buy_md_amount', 0) + df.get('buy_sm_amount', 0)
            sell_total = df.get('sell_elg_amount', 0) + df.get('sell_lg_amount', 0) + \
                        df.get('sell_md_amount', 0) + df.get('sell_sm_amount', 0)
            df['mf_net_ratio'] = (buy_total - sell_total) / (df['amount'] + 1e-8)
            
            # 2. 散户情绪 (小单)
            df['retail_sentiment'] = (df.get('buy_sm_amount', 0) - df.get('sell_sm_amount', 0)) / (df['amount'] + 1e-8)
            
            # 3. 主力净流入 (超大单 + 大单)
            main_buy = df.get('buy_elg_amount', 0) + df.get('buy_lg_amount', 0)
            main_sell = df.get('sell_elg_amount', 0) + df.get('sell_lg_amount', 0)
            df['main_force_ratio'] = (main_buy - main_sell) / (df['amount'] + 1e-8)
            
            # 4. 各类资金占比
            total_amount = df['amount'] + 1e-8
            df['elg_ratio'] = (df.get('buy_elg_amount', 0) + df.get('sell_elg_amount', 0)) / total_amount
            df['lg_ratio'] = (df.get('buy_lg_amount', 0) + df.get('sell_lg_amount', 0)) / total_amount
            df['md_ratio'] = (df.get('buy_md_amount', 0) + df.get('sell_md_amount', 0)) / total_amount
            df['sm_ratio'] = (df.get('buy_sm_amount', 0) + df.get('sell_sm_amount', 0)) / total_amount
            
            # 5. 买卖比率
            df['buy_sell_ratio'] = buy_total / (sell_total + 1e-8)
            
            # 6. 净流入量/金额比率
            df['net_mf_vol_ratio'] = df.get('net_mf_vol', 0) / (df['vol'] + 1e-8)
            df['net_mf_amount_ratio'] = df.get('net_mf_amount', 0) / (df['amount'] + 1e-8)
            
            # 7. 大单小单比率
            large_order = df.get('buy_elg_vol', 0) + df.get('sell_elg_vol', 0) + \
                         df.get('buy_lg_vol', 0) + df.get('sell_lg_vol', 0)
            small_order = df.get('buy_sm_vol', 0) + df.get('sell_sm_vol', 0)
            df['large_order_ratio'] = large_order / (df['vol'] + 1e-8)
            df['small_order_ratio'] = small_order / (df['vol'] + 1e-8)
        else:
            # 无资金流数据时填充 0
            mf_cols = ['mf_net_ratio', 'retail_sentiment', 'main_force_ratio',
                      'elg_ratio', 'lg_ratio', 'md_ratio', 'sm_ratio',
                      'buy_sell_ratio', 'net_mf_vol_ratio', 'net_mf_amount_ratio',
                      'large_order_ratio', 'small_order_ratio']
            for col in mf_cols:
                df[col] = 0.0
        
        return df
    
    def _calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """计算技术指标"""
        close = df['close']
        high = df['high']
        low = df['low']
        
        # RSI
        df['rsi_6'] = self._calculate_rsi(close, 6)
        df['rsi_12'] = self._calculate_rsi(close, 12)
        df['rsi_24'] = self._calculate_rsi(close, 24)
        
        # MACD
        macd_data = self._calculate_macd(close)
        df['macd'] = macd_data['macd']
        df['macd_signal'] = macd_data['signal']
        df['macd_hist'] = macd_data['hist']
        
        # Bollinger Bands
        boll_data = self._calculate_bollinger(close)
        df['boll_upper_ratio'] = (boll_data['upper'] / close - 1) * 100
        df['boll_lower_ratio'] = (boll_data['lower'] / close - 1) * 100
        df['boll_width'] = (boll_data['upper'] - boll_data['lower']) / close * 100
        
        # 均线比率
        df['ma5_ratio'] = (close / close.rolling(5).mean() - 1) * 100
        df['ma10_ratio'] = (close / close.rolling(10).mean() - 1) * 100
        df['ma20_ratio'] = (close / close.rolling(20).mean() - 1) * 100
        df['ma60_ratio'] = (close / close.rolling(60).mean() - 1) * 100
        
        # ATR
        atr = self._calculate_atr(high, low, close)
        df['atr_ratio'] = atr / close * 100
        
        # CCI
        df['cci'] = self._calculate_cci(high, low, close)
        
        # Williams %R
        df['willr'] = self._calculate_willr(high, low, close)
        
        return df
    
    def _calculate_rsi(self, close: pd.Series, period: int) -> pd.Series:
        """计算 RSI"""
        delta = close.diff()
        gain = delta.where(delta > 0, 0).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / (loss + 1e-8)
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _calculate_macd(self, close: pd.Series) -> Dict:
        """计算 MACD"""
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        macd = ema12 - ema26
        signal = macd.ewm(span=9, adjust=False).mean()
        hist = macd - signal
        return {'macd': macd, 'signal': signal, 'hist': hist}
    
    def _calculate_bollinger(self, close: pd.Series, period: int = 20) -> Dict:
        """计算 Bollinger Bands"""
        ma = close.rolling(period).mean()
        std = close.rolling(period).std()
        upper = ma + 2 * std
        lower = ma - 2 * std
        return {'ma': ma, 'upper': upper, 'lower': lower}
    
    def _calculate_atr(self, high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        """计算 ATR"""
        prev_close = close.shift(1)
        tr1 = high - low
        tr2 = abs(high - prev_close)
        tr3 = abs(low - prev_close)
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(period).mean()
        return atr
    
    def _calculate_cci(self, high: pd.Series, low: pd.Series, close: pd.Series, period: int = 20) -> pd.Series:
        """计算 CCI"""
        tp = (high + low + close) / 3
        ma = tp.rolling(period).mean()
        md = tp.rolling(period).apply(lambda x: abs(x - x.mean()).mean())
        cci = (tp - ma) / (0.015 * md + 1e-8)
        return cci
    
    def _calculate_willr(self, high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
        """计算 Williams %R"""
        hh = high.rolling(period).max()
        ll = low.rolling(period).min()
        willr = -100 * (hh - close) / (hh - ll + 1e-8)
        return willr
    
    def _calculate_valuation_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """计算估值相关特征"""
        # PE/PB/PS Z-Score (截面标准化，这里先计算原值，后续做截面标准化)
        df['pe_zscore'] = df.get('pe', 0)
        df['pb_zscore'] = df.get('pb', 0)
        df['ps_zscore'] = df.get('ps', 0)
        
        # 换手率和量比
        df['turnover_rate'] = df.get('turnover_rate', 0)
        df['volume_ratio'] = df.get('volume_ratio', 1)
        
        # 市值排名 (百分位)
        df['total_mv_rank'] = df.get('total_mv', 0)
        
        return df
    
    def _calculate_time_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """计算时间特征"""
        df['trade_date'] = pd.to_datetime(df['trade_date'])
        df['weekday'] = df['trade_date'].dt.dayofweek / 4.0  # 归一化到 [0, 1]
        df['month'] = (df['trade_date'].dt.month - 1) / 11.0  # 归一化到 [0, 1]
        df['is_month_start'] = df['trade_date'].dt.is_month_start.astype(float)
        df['is_month_end'] = df['trade_date'].dt.is_month_end.astype(float)
        return df
    
    def _calculate_return_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """计算收益特征 (用于标签)"""
        close = df['close']
        df['ret_1d'] = close.pct_change(1) * 100
        df['ret_5d'] = close.pct_change(5) * 100
        df['ret_10d'] = close.pct_change(10) * 100
        df['ret_20d'] = close.pct_change(20) * 100
        return df
    
    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """清洗数据"""
        # 删除收盘价为空的行
        df = df.dropna(subset=['close'])
        
        # 特征列填充 0
        for col in self.FEATURES:
            if col in df.columns:
                df[col] = df[col].fillna(0)
        
        # 异常值处理 (winsorize)
        for col in self.FEATURES:
            if col in df.columns:
                df[col] = df[col].clip(lower=-10, upper=10)
        
        return df
    
    def calculate_cross_sectional_stats(
        self, 
        all_stocks_df: pd.DataFrame, 
        date: str
    ) -> Dict:
        """
        计算截面统计量并缓存
        
        Args:
            all_stocks_df: 全市场数据 (某日)
            date: 日期 YYYYMMDD
        
        Returns:
            包含 median 和 mad 的字典
        """
        stats = {'date': date, 'median': [], 'mad': []}
        
        for feat in self.FEATURES:
            if feat in all_stocks_df.columns:
                col = all_stocks_df[feat]
                median = col.median()
                mad = (col - median).abs().median()
                stats['median'].append(float(median) if pd.notna(median) else 0.0)
                stats['mad'].append(float(mad) if pd.notna(mad) else 1.0)
            else:
                stats['median'].append(0.0)
                stats['mad'].append(1.0)
        
        # 保存缓存
        cache_file = self.stats_cache_dir / f"{date}.json"
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False)
        
        logger.debug(f"Stats cached for {date}")
        return stats
    
    def load_stats_cache(self, date: str) -> Optional[Dict]:
        """
        加载统计量缓存
        
        Args:
            date: 日期 YYYYMMDD
        
        Returns:
            缓存的统计量字典
        """
        cache_file = self.stats_cache_dir / f"{date}.json"
        if cache_file.exists():
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    def get_latest_stats_cache(self) -> Optional[Dict]:
        """
        获取最近一个可用日期的统计缓存
        
        Returns:
            最近一个可用日期的统计缓存字典
        """
        # 获取所有缓存文件
        cache_files = list(self.stats_cache_dir.glob("*.json"))
        if not cache_files:
            return None
        
        # 按文件名排序，获取最新的文件
        cache_files.sort(key=lambda x: x.name, reverse=True)
        
        # 尝试加载最近的几个缓存文件
        for cache_file in cache_files[:10]:  # 尝试前10个最近的文件
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    stats = json.load(f)
                    logger.info(f"Found recent stats cache from {stats.get('date')}")
                    return stats
            except Exception as e:
                logger.error(f"Failed to load cache file {cache_file}: {e}")
                continue
        
        return None
    
    def generate_stats_cache(self, date: str, use_prev_date=True) -> Optional[Dict]:
        """
        生成指定日期的统计缓存
        
        Args:
            date: 日期 YYYYMMDD
            use_prev_date: 如果没有当日数据，是否尝试使用前一天的数据
        
        Returns:
            生成的统计量字典
        """
        from data.downloader import TushareDownloader
        from pathlib import Path
        import pandas as pd
        from datetime import datetime, timedelta
        
        # 检查缓存是否已存在
        cache_file = self.stats_cache_dir / f"{date}.json"
        if cache_file.exists():
            logger.info(f"Stats cache already exists for {date}")
            return self.load_stats_cache(date)
        
        logger.info(f"Generating stats cache for {date}")
        
        try:
            # 初始化下载器
            downloader = TushareDownloader()
            
            # 获取主板股票列表
            stocks_df = downloader.get_main_board_stocks()
            stock_list = stocks_df['ts_code'].tolist()
            logger.info(f"Got {len(stock_list)} main board stocks")
            
            # 收集当日所有股票数据
            all_stocks_data = []
            
            # 优先使用本地已有的数据，处理前20只股票
            for ts_code in stock_list[:20]:
                file_path = Config.RAW_DATA_DIR / f"{ts_code.replace('.', '_')}.parquet"
                df = None
                
                # 首先尝试读取本地数据
                if file_path.exists():
                    # 读取本地数据
                    df = pd.read_parquet(file_path)
                    logger.info(f"Loaded local data for {ts_code}, shape: {df.shape}")
                    
                    # 检查日期格式
                    if df['trade_date'].dtype == 'object':
                        # 尝试将日期转换为YYYYMMDD格式
                        df['trade_date'] = pd.to_datetime(df['trade_date']).dt.strftime('%Y%m%d')
                    
                    # 打印日期范围
                    logger.info(f"{ts_code}: Date range in local data: {df['trade_date'].min()} to {df['trade_date'].max()}")
                    
                    # 检查是否有指定日期的数据
                    has_date_data = (date in df['trade_date'].values)
                    if not has_date_data:
                        logger.warning(f"No data for {ts_code} on {date} in local file, downloading...")
                        df = None  # 标记需要重新下载
                else:
                    logger.info(f"No local data file for {ts_code}, downloading...")
                
                # 如果本地数据不包含指定日期，或者本地文件不存在，重新下载数据
                if df is None:
                    # 下载该股票数据，只下载最近30天的数据
                    end_date = date
                    start_date = (datetime.strptime(date, '%Y%m%d') - timedelta(days=30)).strftime('%Y%m%d')
                    df = downloader.download_stock_data(ts_code, start_date=start_date, end_date=end_date)
                    if df is not None and not df.empty:
                        # 检查日期格式
                        if df['trade_date'].dtype == 'object':
                            df['trade_date'] = pd.to_datetime(df['trade_date']).dt.strftime('%Y%m%d')
                        
                        # 保存到本地
                        df.to_parquet(file_path, index=False)
                        logger.info(f"Downloaded data for {ts_code}, shape: {df.shape}")
                        logger.info(f"{ts_code}: Date range in downloaded data: {df['trade_date'].min()} to {df['trade_date'].max()}")
                    else:
                        logger.error(f"Failed to download data for {ts_code}")
                        continue
                
                # 筛选指定日期的数据
                df_date = df[df['trade_date'] == date]
                if not df_date.empty:
                    logger.info(f"Found data for {ts_code} on {date}, shape: {df_date.shape}")
                    all_stocks_data.append(df_date)
                else:
                    logger.warning(f"No data for {ts_code} on {date} after download")
                    # 检查是否有最近的日期数据
                    recent_dates = df['trade_date'].sort_values(ascending=False).head(5)
                    logger.info(f"{ts_code}: Recent dates available: {list(recent_dates)}")
            
            logger.info(f"Collected data for {len(all_stocks_data)} stocks")
            
            if all_stocks_data:
                # 合并所有股票的数据
                all_stocks_df = pd.concat(all_stocks_data, ignore_index=True)
                logger.info(f"Merged data shape: {all_stocks_df.shape}")
                
                # 预处理数据
                processed_data = []
                for _, group in all_stocks_df.groupby('ts_code'):
                    try:
                        processed = self.process_daily_data(group)
                        if not processed.empty:
                            processed_data.append(processed.tail(1))  # 只取最新一行
                            logger.debug(f"Processed data for {group['ts_code'].iloc[0]}, shape: {processed.shape}")
                    except Exception as e:
                        logger.error(f"Failed to process data for {group['ts_code'].iloc[0]}: {e}")
                        continue
                
                logger.info(f"Processed data for {len(processed_data)} stocks")
                
                if processed_data:
                    processed_df = pd.concat(processed_data, ignore_index=True)
                    logger.info(f"Final processed data shape: {processed_df.shape}")
                    
                    # 检查是否包含所有必要的特征列
                    missing_features = [feat for feat in self.FEATURES if feat not in processed_df.columns]
                    if missing_features:
                        logger.warning(f"Missing features: {missing_features}")
                        # 为缺失的特征创建默认值列
                        for feat in missing_features:
                            processed_df[feat] = 0.0
                    
                    # 计算截面统计量
                    stats = self.calculate_cross_sectional_stats(processed_df, date)
                    logger.info(f"Generated stats cache for {date}")
                    return stats
                else:
                    logger.warning(f"No processed data available for {date}")
            else:
                logger.warning(f"No data available for {date}")
                
                # 如果没有当日数据，尝试使用前一天的数据
                if use_prev_date:
                    # 计算前一天的日期
                    prev_date = (datetime.strptime(date, '%Y%m%d') - timedelta(days=1)).strftime('%Y%m%d')
                    logger.info(f"Trying to generate stats cache for previous day: {prev_date}")
                    stats = self.generate_stats_cache(prev_date, use_prev_date=False)
                    if stats is not None:
                        return stats
                
                # 如果还是没有数据，直接返回最近的可用缓存
                logger.warning(f"No data available for {date} and previous day, returning latest available cache")
                return self.get_latest_stats_cache()
        
        except Exception as e:
            logger.error(f"Failed to generate stats cache: {e}")
            import traceback
            traceback.print_exc()
        
        return None
    
    def apply_zscore(
        self, 
        df: pd.DataFrame, 
        stats: Dict = None
    ) -> pd.DataFrame:
        """
        应用 Z-Score 标准化
        
        使用 (X - median) / (1.4826 * mad) 公式
        
        Args:
            df: 输入 DataFrame
            stats: 统计量字典 (含 median 和 mad)
        
        Returns:
            标准化后的 DataFrame
        """
        df = df.copy()
        
        if stats is None:
            # 在线计算
            for feat in self.FEATURES:
                if feat in df.columns:
                    df[feat] = robust_zscore(df[feat])
        else:
            # 使用缓存的统计量
            for i, feat in enumerate(self.FEATURES):
                if feat in df.columns:
                    median = stats['median'][i]
                    mad = stats['mad'][i]
                    mad = max(mad, 1e-8)  # 避免除零
                    df[feat] = (df[feat] - median) / (1.4826 * mad)
        
        return df
    
    def process_all_data(self, save_processed: bool = True) -> pd.DataFrame:
        """
        处理所有原始数据
        
        Returns:
            处理后的合并 DataFrame
        """
        raw_dir = Config.RAW_DATA_DIR
        all_dfs = []
        
        parquet_files = list(raw_dir.glob("*.parquet"))
        total = len(parquet_files)
        
        logger.info(f"Processing {total} files...")
        
        for i, parquet_file in enumerate(parquet_files):
            if 'index_' in parquet_file.name:
                continue
            
            try:
                df = pd.read_parquet(parquet_file)
                
                # 主板过滤
                if 'ts_code' in df.columns:
                    ts_code = df['ts_code'].iloc[0]
                    if not is_main_board(ts_code):
                        continue
                
                # 处理特征
                df = self.process_daily_data(df)
                all_dfs.append(df)
                
                if (i + 1) % 100 == 0:
                    logger.info(f"Processed {i + 1}/{total} files")
                    
            except Exception as e:
                logger.error(f"Error processing {parquet_file}: {e}")
                continue
        
        if not all_dfs:
            logger.warning("No data processed")
            return pd.DataFrame()
        
        # 合并
        merged_df = pd.concat(all_dfs, ignore_index=True)
        merged_df = merged_df.sort_values(['ts_code', 'trade_date']).reset_index(drop=True)
        
        # 按日期计算截面统计量
        logger.info("Calculating cross-sectional statistics...")
        for date, group in merged_df.groupby(merged_df['trade_date'].dt.strftime('%Y%m%d')):
            self.calculate_cross_sectional_stats(group, date)
        
        # 保存处理后的数据
        if save_processed:
            save_path = Config.PROCESSED_DATA_DIR / "all_features.parquet"
            merged_df.to_parquet(save_path, index=False)
            logger.info(f"Processed data saved to {save_path}")
        
        return merged_df


# 便捷函数
def preprocess_stock_data(df: pd.DataFrame) -> pd.DataFrame:
    """便捷预处理函数"""
    preprocessor = Preprocessor()
    return preprocessor.process_daily_data(df)
